﻿app.controller("headerController", ["$scope", "$rootScope","$state", function ($scope, $rootScope,$state) {
    $scope.goBack = function () {
        var back = $rootScope.$previousState;
        //var params = $rootScope.pa
        if (back.name == "app.page") {
            $state.go("app.page", { page: $rootScope.lastPage.pageNumber });
        }
        else {
            $state.go(back.name);
        }
    }
    $scope.search = function () {
        debugger;
        $rootScope.searchIcon = true;
        $state.go("app.search");
    }
}]);