﻿app.factory("contacts", ["$q",  function ($q) {
    
    return {
        getContacts: function () {
            var deferred = $q.defer();

            navigator.contacts.find(
              [navigator.contacts.fieldType.displayName],

              function(c){
                
                  var contacts = [];
                  try {
                      for (var i = 0, len = c.length; i < len; i++) {
                          if (c[i].phoneNumbers) {
                              for (var j = 0; j < c[i].phoneNumbers.length; j++) {
                                  contacts.push(c[i].phoneNumbers[j].value.replace(/\s/g, ''));
                              }
                          }
                      }
                      deferred.resolve(contacts);
                  }
                  catch (ex) {
                      alert(JSON.stringify(ex));
                      deferred.reject(ex);
                  }

                 
              },
              function(err){
                  deferred.reject(err);
              
              });
        
            return deferred.promise;
         }
    }
}]);