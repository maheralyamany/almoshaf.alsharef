﻿app.factory("target", ["$state", "localStorage", "enums", "localNotification", "groupAdd", "user", "ionicLoading", "guid", "ayatData", "$filter", "memorizedayat", "$rootScope", function ($state, localStorage, enums, localNotification, groupAdd, user, ionicLoading, guid, ayatData, $filter, memorizedayat, $rootScope) {

    var storageKey = "targets";

    
    var service = {
        storageKey : "targets",
        allTargets: [],
        data: {
            id: null,
            memorizeMode: "",
            targetType: 1,
            ayatCount: 5,
            surahId: 1,
            juzId: 1,
            title: "",
            memorizeStatus: enums.memorizeStatus.loadingMemorize,
            periodType: 1,
            // notificationTime: new Date(),
            notificationDayIndex: 0,
            startDate: new Date().getTime(),
            notificationID: null,
            notificationMode: enums.notificationMode.on,
            notificationTitle: "ايقاف",
            progress: 0,
            startPage: 1,
            endPage: 1,
            startAya: 1,
            targetMode : 1
        },

        getTargetTitle: function (targetType, surahId, juzId,pageFrom,pageTo) {
            try{
                var targetTitle = " حفظ ";
                if (targetType == enums.targetType.juz) {
                    targetTitle += ayatData.juzs[juzId - 1].Name;
                }
                else if (targetType == enums.targetType.page) {
                    targetTitle += " من صفحة " + $rootScope.getArabicNumber(pageFrom) + " الى " + $rootScope.getArabicNumber(pageTo);
                }
                else {
                    targetTitle += "سورة " + ayatData.surahs[surahId - 1].Name;
                }
                return targetTitle;
            }
            catch (ex) {
                alert(JSON.stringify(ex));
            }
        },

        getNotificationTime: function (startDate,periodType) {

            var daysOfWeek = enums.weekDays;
            var notificationTime = "";
            var serNotificationTime = {
                hour: new Date(this.data.startDate).getHours(),
                minute: new Date(this.data.startDate).getMinutes(),
                ampm: new Date(this.data.startDate).getHours() > 11 ? "pm" : "am",
            }

            if (periodType == enums.periodType.weekly) {
                notificationTime = " يوم " + daysOfWeek[new Date(this.data.startDate).getDay()].name + " الساعة " + serNotificationTime.minute + " : " + service.getHour(serNotificationTime) + service.getAmPm(serNotificationTime);
                return notificationTime;
            }
            else {
                notificationTime = " الساعة " + serNotificationTime.minute + " : " + service.getHour(serNotificationTime) + service.getAmPm(serNotificationTime);
                return notificationTime;
            }
        },
        getHour: function (serNotificationTime) {
            var hour = serNotificationTime.hour;
            if (hour>12 ) {
                hour -= 12;
            }
            if(hour==0){hour=12}
            return hour;
        },
        getAmPm: function (serNotificationTime) {
            var hour = serNotificationTime.hour;
            var ampm="ص";
            if (hour >= 12) {
                ampm ="م";
            }
            return ampm;
        },
        getProgressDays: function (item) {
            //debugger;
            var noOfDays;
            var noOfAyah;
            var noOfMemorizedAyat;
            if (typeof (item.noOfAyah) == "undefined") {
                noOfAyah = service.getTargetAyat(item).length;

                item.noOfAyah = noOfAyah;
            }
            //console.log(service.getTargetAyat(item));
            //if (typeof (item.noOfMemorizedAyat) == "undefined") {
                if (item.targetType == enums.targetType.juz) {

                    noOfMemorizedAyat = memorizedayat.getJuzMemorizedAyat(item.juzId,item).length;
                }
                else if (item.targetType == enums.targetType.page) {
                    noOfMemorizedAyat = memorizedayat.getPagesMemorizedAyat(item.pageFrom, item.pageTo,item).length;

                }
                else {
                    noOfMemorizedAyat = memorizedayat.getSurahMemorizedAyat(item.surahId,item).length;
                }
                item.noOfMemorizedAyat = noOfMemorizedAyat;
            //}
            if (item.periodType == enums.periodType.daily) {
                noOfDays = (item.noOfAyah - item.noOfMemorizedAyat) / item.ayatCount;
            }
            else {
                noOfDays = Math.ceil(((item.noOfAyah - item.noOfMemorizedAyat) / item.ayatCount)) * 7;
            }
            item.noOfDays = Math.ceil(noOfDays);
          //  item.noOfMemorizedAyat = noOfMemorizedAyat;
            item.progress = Math.ceil((item.noOfMemorizedAyat / item.noOfAyah) * 100);
            return item;
        },
        resetTargetData: function () {
            this.data = {

                id: null,
                memorizeMode: "",
                targetType: 1,
                ayatCount: 5,
                surahId: 1,
                juzId: 1,
                notificationMode: enums.notificationMode.on,
                periodType: 1,
                // notificationTime: new Date(),
                notificationDayIndex: 0,
                notificationTitle: "ايقاف",
                startDate: new Date().getTime(),
                notificationID: null,
                startPage: 1,
                endPage: 1,
                startAya: 1,
                targetMode: 1
            }


        },


        saveTarget: function () {


            // alert("saving");

            if (this.data.memorizeMode == enums.memorizeMode.individual) {
                alert("individual");

                if (this.data.id == null) //add mode
                {
                    //var memorized= 0;
                    //if (this.data.targetType == enums.targetType.juz)
                    //{
                    //    memorized = memorizedayat.getJuzMemorizedAyat(this.data.juzId,this.data);
                      
                    //}
                    //else {
                    //    memorized = memorizedayat.getSurahMemorizedAyat(this.data.surahId,this.data);

                    //}
                    //if (memorized.length > 0) {
                    //    this.data.startAya = memorized[memorized.length - 1].id + 1;
                    //}
                    //else {
                        this.data.startAya = 1;
                    //}
                    this.addTarget();
                }
                else { //update mode
                    this.updateTarget();
                }
                service.resetTargetData();
                $state.go("app.target-list")
            }


            else {
                alert("save group");
                this.saveTargetNotification();
                alert(groupAdd.data.members);
                groupAdd.addGroup(groupAdd.data.id, user.data.profile.id, groupAdd.data.name, groupAdd.data.members, this.data.targetType, this.data.periodType, this.data.juzId, this.data.surahId
                    , this.data.ayatCount, this.data.startDate, this.data.notificationID).then(function (result) {
                        if (result != 0) {
                            ionicLoading.showMessage("تم حفظ بيانات المجموعة بنجاح").then(function () {
                                $state.go("app.group")
                            });
                        }
                        else {
                            alert("error");
                        }

                    });
                groupAdd.resetData();
                service.resetTargetData();
            }




        },

        addTarget: function () {
           // alert(this.data.notificationMode);
            this.data.id = guid.generate(); //generate a unique id for the target
            if (this.data.targetType == enums.targetType.juz)
            {
                var juz = ayatData.getjuz(this.data.juzId);
                this.data.startPage = juz.StartPage;
                this.data.endPage=juz.EndPage
            }
            else if (this.data.targetType == enums.targetType.page) {
                debugger;
                this.data.startPage = this.data.pageFrom;
                this.data.endPage = this.data.pageTo;
            }
            else {
                var surah = ayatData.getSurah(this.data.surahId);
                this.data.startPage = surah.StartPage;
                this.data.endPage = surah.EndPage
            }
            if (this.data.notificationMode == enums.notificationMode.on) {
                this.saveTargetNotification();
            }
            this.data.title= service.getTargetTitle(this.data.targetType, this.data.surahId, this.data.juzId, this.data.startPage, this.data.endPage)
            localStorage.append(storageKey, this.data);

        },

        updateTarget: function () {
            var targetObj = null;

            var storedTargets = localStorage.get(storageKey);

            for (var i = 0; i < storedTargets.length; i++) {
                if (storedTargets[i].id == this.data.id) {
                    //alert(this.data.notificationMode)
                    targetObj = storedTargets[i];
                    break;
                }

            }
            angular.copy(this.data, targetObj);
            localStorage.set(storageKey, storedTargets);
            //alert("notification mode"+ this.data.notificationMode)
            if (this.data.notificationMode == enums.notificationMode.on) {
                this.saveTargetNotification();
            }

        },

        saveTargetNotification: function () {
            //  alert("saving notifications");
      
            var targetTitle = this.getTargetTitle(service.data.targetType, service.data.surahId, service.data.juzId, service.data.pageFrom, service.data.pageTo);
            alert(targetTitle)

            var notificationTime = new Date(this.data.startDate);
            notificationTime.setSeconds(0);
            notificationTime.setMilliseconds(0);
            //   window.plugin.notification.local.hasPermission(function (granted) {
            //    alert('Permission has been granted: ' + granted);
            // });
            //window.plugin.notification.local.promptForPermission();

            if (typeof (cordova) != "undefined") {
                var frequency = "day";
                if (this.data.periodType == enums.periodType.weekly) {
                    frequency = "week";
                }
                var notification = {
                    smallIcon: 'res://icon.png',
                    icon: 'res://icon.png',
                    title: "تذكير بموعد حفظ ورد " + targetTitle,
                    //text: "يوم" + new Date(this.data.startDate).getDate() + " الساعة " + new Date(this.data.startDate).getHours() + " : " + new Date(this.data.startDate).getMinutes(),
                    text: "تذكير بحفظ ورد عدد " + service.data.ayatCount + "ايات",
                    data: {
                        targetData: service.data
                    },

                }
                //If the target already has notification id, then override it
                if (this.data.notificationID) {
                    notification.id = this.data.notificationID;
                }
        
                localNotification.scheduleRepeatedNotification(notification, frequency,
                notificationTime
                ).then(function (res) {

                    alert("notification saved " + notification.id);

                });
                service.data.notificationID = notification.id;
            }
        
        },

        cancelNotification: function (notificationId) {

            if (!notificationId) {
                notificationId = this.data.notificationID;
            }
            //   alert(notificationId);
            return localNotification.cancelNotification(notificationId);
        },

        clearTargets: function () {
            localStorage.remove(storageKey);
            alert("canceling notification");
            service.cancelNotification(this.data.notificationID).then(function (res) {
                alert("notification cancelled" + JSON.stringify(res));
            });

        },

        getAllTargets: function () {
            ;
            var test = localStorage.get(storageKey);
            angular.forEach(test, function (item, key) {
                ;
                item.title = service.getTargetTitle(item.targetType, item.surahId, item.juzId,item.pageFrom,item.pageTo);
                item = service.getProgressDays(item);
                if (item.progress == 100) {
                    item.isDone = true;
                    item.memorizeStatusName = "تم الحفظ";
                }
                else {
                    item.isDone = false;
                    item.memorizeStatusName = "جاري الحفظ";
                }
                if (item.notificationMode == enums.notificationMode.on)
                    item.notificationTitle = "ايقاف";
                else
                    item.notificationTitle = "تشغيل";
                test[key] = item;
            });
            //this.data.title = this.getTargetTitle(t.targetType,t.surahId,t.juzId);
            //localStorage.append(storageKey, this.data);
            //;
            return test;
        },


        getTargetByID: function (id) {
            var storedTargets = localStorage.get(storageKey);
            var res;
            for (var i = 0; i < storedTargets.length; i++) {
                if (storedTargets[i].id == this.data.id) {
                    storedTargets[i].title = service.getTargetTitle(storedTargets[i].targetType, storedTargets[i].surahId, storedTargets[i].juzId, storedTargets[i].pageFrom, storedTargets[i].pageTo);

                    return storedTargets[i];
                    break;
                }

            }

        },


        getTargetAyat: function (targetData) {
            ;
            if (targetData.targetType == enums.targetType.juz) {
                return ayatData.getJuzAyat(targetData.juzId);
            }
            else if (targetData.targetType == enums.targetType.page) {
                return ayatData.getpagesAyat(targetData.pageFrom, targetData.pageTo);

            }
            else {
                return ayatData.getSurahAyat(targetData.surahId);
            }
        },

        setTargetByID: function (id) {
            var storedTargets = localStorage.get(storageKey);
            var res;
            for (var i = 0; i < storedTargets.length; i++) {
                if (storedTargets[i].id == id) {
                    service.data = storedTargets[i]
                    return storedTargets[i];
                    break;
                }

            }
        },

        cancelFinishedTargetsNotification: function () {
            var allTargets = service.getAllTargets();
            for (var i = 0 ; i < allTargets.length ; i++) {
                if (allTargets[i].isDone==true) {
                    service.cancelNotification(allTargets[i].notificationID);
                }
            }
        },
        deleteTarget: function () {
            var storedTargets = localStorage.get(storageKey);

            for (var i = 0; i < storedTargets.length; i++) {
                if (storedTargets[i].id == this.data.id) {
                    //alert(this.data.notificationMode)
                    storedTargets.splice(i, 1);
                    break;
                }

            }
            localStorage.set(storageKey, storedTargets);
            service.cancelNotification(this.data.notificationID);

        },
        //setTargetPages: function (targetData) {

        //}
    }

    return service;

}]);