﻿app.factory("group", ["httpHandler", "$q", "memorizedayat", function (httpHandler, $q, memorizedayat) {
    var service = {
        getGroups: function (Id) {
            var deferred = $q.defer();
            httpHandler.get("Group/GetGroups", { iUserID: Id }, true).then(function (results) {
                deferred.resolve(results);
            });

            return deferred.promise;
        },
        syncAyatLocalToServer: function ()
        {  
            memorizedayat.syncMemorizedAyatLocalToServer();
        }
        
    }

    return service;
}]);