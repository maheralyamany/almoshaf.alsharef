﻿app.factory("settings", ["localStorage", "$q", "enums", "$rootScope", function (localStorage, $q, enums, $rootScope) {
    debugger
    var service = {
        key: "settings",
        settingsData :{
            markMemorizedAyat: false,
            nightMode: false,
            fullScreen: true,
            recitationId: 1,
            keepAwake: true
        },

        setSettingsData: function () {
            var settings = localStorage.get(service.key);
            if (typeof (settings) == "undefined") {
                service.setDefaultValues();
            }
            else {
                var mergedData = {};
                angular.extend(mergedData, service.settingsData, settings)
                service.settingsData = mergedData;
            }
       
            return service.settingsData;
        },
        setDefaultValues :function(){
            service.settingsData = {
                markMemorizedAyat: false,
                nightMode: false,
                fullScreen: true,
                recitationId: 1,
                keepAwake: true
            }
            service.saveSettings();
        },

        saveSettings: function () {
            localStorage.set(service.key, service.settingsData);
        },
     
        setMarkMemorizedAyatValue:function(value)
        {
            service.settingsData.markMemorizedAyat = value;
            service.saveSettings();
        },
        setRecitationIdValue: function (value) {
            service.settingsData.recitationId = value;
            service.saveSettings();
        },
        setNightModeValue: function (value) {
            service.settingsData.nightMode = value;
            $rootScope.nightMode = service.settingsData.nightMode;
            service.saveSettings();
        },
        setFullScreenValue: function (value) {
            var devicePlatform = device.platform;

            if (value) {
                if (devicePlatform == "Android")
                    AndroidFullScreen.immersiveMode()
                else
                    StatusBar.hide();
            }
            else {
                if (devicePlatform == "Android")
                    AndroidFullScreen.showSystemUI();
                else
                    StatusBar.show();
                //AndroidFullScreen.showUnderStatusBar();
                //AndroidFullScreen.showUnderSystemUI();
                //AndroidFullScreen.showSystemUI();
            }
            service.settingsData.fullScreen = value;
            service.saveSettings();
        },
        setkeepAwake: function (value) {
            service.settingsData.keepAwake = value;
            service.saveSettings();
        },


        
    }
    service.settingsData = service.setSettingsData();

     return service;

}])
