﻿app.factory("search", ["moshafdata" ,"$q", function (moshafdata,$q) {


    function createReplaceRegex(word) {

        var charactersList = word.split("");
        var regStr = "(";
        for (var i = 0; i < charactersList.length; i++) {
            var character = charactersList[i];
            regStr += character + "{1}" + "[^\u0620-\u064A]*"

        }
        regStr += "[\\S]*)"
        console.log(regStr)
        return new RegExp(regStr)
    }

    var service = {
        searchKey: {
            key: "",
            result: []
        },
        removeArabicAccent: function (value) {
            return value
            .replace(/’/g, '').replace(/َ/g, '').replace(/ِ/g, '').replace(/ْ/g, '')
                .replace(/ّ/g, '').replace(/ً/g, '').replace(/ٌ/g, '').replace(/ٍ/g, '')
                .replace(/ٍ/g, '').replace(/~/g, '')
            ;
        },
        searchInQuran: function (searchKey) {
            //debugger;
            var deferred = $q.defer();
            var verseSearchKey = this.removeArabicAccent(searchKey);
            moshafdata.executeQuery("select * from Ayah where verseClean LIKE '%" + verseSearchKey + "%'").then(function (res) {
                //debugger;
                deferred.resolve(res);
                service.searchKey = {key:searchKey,result:res};
            })
            return deferred.promise;
        }

    }
    //str.replace(/(ض{1}[^\u0620-\u064A]*ر{1}[^\u0620-\u064A]*ب{1}[\S]*)/gi,"<span>$1</span>")
   
    return service;
}]);