﻿app.factory("groupAdd", ["httpHandler", "$q", "contacts", "ionicLoading", function (httpHandler, $q, contacts, ionicLoading) {
      
    var service = {

        data: {
            id: 0,
            name: "",
            members: []
        },

        resetData:function(){
            this.data = {
                id: 0,
                name: "",
                members: [],
            };
        },

        getAllMembers: function (groupId) {
            var deferred = $q.defer();
            ionicLoading.show({ templateText: "جاري التحميل برجاء الانتظار" });
            contacts.getContacts().then(function (result) {
                httpHandler.post("User/GetUsersRegistered", { GroupId: groupId, arrUsers: result, iUserID: 0 }, true).then(function (results) {
                    deferred.resolve(results);

                });
            });

            return deferred.promise;
        },

        getGroupWithAllDetails: function (IdGroup,IdUser) {
            var deferred = $q.defer();
 
            httpHandler.get("Group/GetGroupsWithAllDetails", { GroupID: IdGroup, iUserID: IdUser }, true).then(function (result) {
                deferred.resolve(result);

            });

            return deferred.promise;
        },
        
        addGroup: function (Id, UserId, strGroupName, UsersIds, targetType, periodType, juzId, surahId, ayatCount, notificationTime, notificationID) {
            var deferred = $q.defer();
            httpHandler.post("Group/AddGroup", { Id: Id, iUserID: UserId, strGroupName: strGroupName, UsersIds: UsersIds
            , TargetTypeID: targetType, PeriodTypeID: periodType, JuzID: juzId, SurahID: surahId, AyaatCount: ayatCount, NotificationTime: notificationTime, NotificationID: notificationID
            }, true).then(
                
                function (result) {
                    deferred.resolve(result);
                }
                );
            return deferred.promise;
        },

        deleteUserFromGroup: function (IdUser,IdGroup) {
            var deferred = $q.defer();
            httpHandler.post("Group/DeleteUserFromGroup", { UserId: IdUser, GroupId: IdGroup , iUserID: 0}, true).then(

                function (result) {
                    deferred.resolve(result);
                }
                );
            return deferred.promise;
        },

        getAllMembersProgress: function (groupId,targetId) {
            var deferred = $q.defer();
            httpHandler.get("GroupTarget/GetGroupUsersProgress", { GroupId: groupId }, true).then(function (results) {
                deferred.resolve(results);

            });
     
      

        return deferred.promise;
        },

        sendNotificationToLateUser: function (userId, groupId) {
            var deferred = $q.defer();
            httpHandler.get("Group/SendLateNotification", { UserId: userId, GroupId: groupId, iUserID: 0 }, true).then(function (results) {
                deferred.resolve(results);

            });



            return deferred.promise;
        },

    }

    return service;
}]);