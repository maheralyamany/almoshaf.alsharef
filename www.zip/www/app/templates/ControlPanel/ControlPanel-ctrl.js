﻿app.controller("ControlPanelController", ["toast", "$scope", "$state", "$rootScope", "enums", "device", "file", "fileTransfer", "network", "permissions", "$ionicModal", "moshafdb", "ayatData", "ayatTafseer", "$q", "settings", "mark", "$ionicHistory", function (toast,$scope, $state, $rootScope, enums, device, file, fileTransfer, network, permissions, $ionicModal, moshafdb, moshafdata, ayatData, ayatTafseer, $q, settings, mark, $ionicHistory) {
    //, "toast"
    //, toast
    /*moshaf-copy*/
    $rootScope.closeLoadingModal = function (MoshafId) {
        $scope.downloading=false;
        $rootScope.modal.hide();
    }
    
    $ionicModal.fromTemplateUrl('app/templates/popovers/loading.html', {
        scope: $rootScope,
        animation: 'slide-in-up',
    }).then(function (modal) {
        $rootScope.modal = modal;

    });

    $scope.mgoBack = function () {
        $ionicHistory.goBack();
    }

    $scope.goToRemoveTelawa = function () {
        $state.go("remove-telawa");
    }

    

    /*remove telawa*/

    $scope.init = function () {
        $rootScope.canCancel=true;
        var directory = "";
        if (device.getPlatform() == "ios") {
            directory = cordova.file.dataDirectory;
        }
        else directory = cordova.file.externalRootDirectory;

        window.resolveLocalFileSystemURL(directory + enums.appData.audioTargetPath, function (fileSystem) {
            var reader = fileSystem.createReader();
            reader.readEntries(
                function (entries) {
                    $scope.telawat = entries;
                    angular.forEach(entries, function (value, key) {
                        console.log(value);
                        console.log(key);
                        window.resolveLocalFileSystemURL(directory + enums.appData.audioTargetPath + "/" + value.name, function (fileSystem) {
                            var reader = fileSystem.createReader();
                            reader.readEntries(
                                function (entries) {
                                    if (entries.length == 0) {
                                        $scope.telawat[key].canDelete = false;
                                    } else {
                                        $scope.telawat[key].canDelete = true;
                                    }
                                },
                                function (err) {
                                    console.log(err);
                                }
                            );
                        }, function (err) { console.log(err); });

                    });
                },
                function (err) {
                    console.log(err);
                }
            );
        }, function (err) { console.log(err); });
        $scope.enums = enums;
        $rootScope.hideMem = true;
    }
    $scope.deleteTelawa = function (telawa, index) {
        var directory = "";
        if (device.getPlatform() == "ios") {
            directory = cordova.file.dataDirectory;
        }
        else directory = cordova.file.externalRootDirectory;
        window.resolveLocalFileSystemURL(directory + enums.appData.audioTargetPath + "/" + telawa.name, function (fileSystem) {
            var reader = fileSystem.createReader();
            reader.readEntries(
                function (entries) {
                    var path = directory + enums.appData.audioTargetPath + "/" + telawa.name;
                    $scope.telawaAudios = entries;
                    angular.forEach($scope.telawaAudios, function (value, key) {
                        file.removeFile(value.name, path).then(function (removedAudio) {
                            //$scope.telawat=$scope.telawat.filter(x=>x.name!=telawa.name);
                        });
                    });
                    $scope.telawat[index].canDelete = false;
                    var msg = "تم الحذف بنجاح";
                    toast.info("", msg);
                },
                function (err) {
                    console.log(err);
                }
            );
        }, function (err) { console.log(err); });

    }
    $scope.goToTelawaSurahs = function (selectedTelawa) {
        $rootScope.selectedTelawa = selectedTelawa;
        $state.go("app.telawa-surahs");
    }

    
    $scope.init();
}]);
