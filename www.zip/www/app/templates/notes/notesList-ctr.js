﻿app.controller("notesController", ["$scope", "$state", "localStorage", "notes", "$rootScope", "ionicPopup", "toast", function ($scope, $state, localStorage, notes, $rootScope, ionicPopup, toast) {

    $scope.deleteNote = function (note) {
        var confirm = ionicPopup.confirm("تاكيد", "هل تريد حذف  الخاطرة", "الغاء", "نعم").then(function (confirm) {
            alert(confirm)
            if (confirm) {
                notes.deleteNote(note.ayaId);
                $scope.notesList = notes.getNotesList();
                var msg = "تم حذف خاطرة   " + " " + " آية" + " " + $scope.getArabicNumber(note.ayaNumber) + " " + "صفحة  " + " " + $scope.getArabicNumber(note.pageNumber);
                toast.info("", msg)
            }
        })
     
    }
    $scope.init = function () {
 
        $rootScope.activePage = "notes";
        $scope.notesList = notes.getNotesList();

    }

    $scope.breakLines = function (text) {
      return  text.replace(new RegExp('\n', 'g'), "<br />")
    }
    $scope.init();
}]);