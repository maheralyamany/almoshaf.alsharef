﻿
app.controller("searchResultController", ["$scope", "moshafdata", "$state", "$rootScope", "$sce", function ($scope, moshafdata, $state, $rootScope, $sce) {
    //$rootScope.showMenu = false;
    //$scope.$on('$ionicView.beforeEnter', function (event, viewData) {
    //    debugger;
    //    viewData.enableBack = true;
    //});
    $scope.getHtml = function (text) {
        return $sce.trustAsHtml(text);
    }
    $scope.ayas = moshafdata.searchData.searchResult;
    $scope.number = $scope.ayas.length;
    $scope.searchKey = moshafdata.searchData.searchKey
    $scope.search = function () {
        debugger;
    }
}]);


