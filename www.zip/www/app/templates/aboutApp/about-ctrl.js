﻿app.controller("aboutController", ["$scope", "$rootScope", "enums", function ($scope, $rootScope, enums) {
    $scope.PageName = 'عن التطبيق';
    $rootScope.activePage = "about";
}]);
