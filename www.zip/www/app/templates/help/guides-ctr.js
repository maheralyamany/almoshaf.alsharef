﻿app.controller("guidesController", function ($scope) {

});