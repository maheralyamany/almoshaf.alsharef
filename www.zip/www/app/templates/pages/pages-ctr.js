﻿app.controller("pagesController", ["$scope", "moshafdata", "$state", "$ionicSideMenuDelegate", "$rootScope", "enums", function ($scope, moshafdata, $state, $ionicSideMenuDelegate, $rootScope, enums) {
    //$ionicSideMenuDelegate.canDragContent(false);
    $rootScope.appMode = enums.appModes.read;
    $rootScope.activePage = "suar";
    $rootScope.activeTab = "pages";
    $scope.model = { pageNumber: 1 };
    $scope.addValue = function (value) {
        //if (num > 604 || num < 1) {
        //    $scope.pageNumber = num;
        //}
        if (!($scope.model.pageNumber > 0)) {
            $scope.model.pageNumber = 0;
        }
        //num = $("#num").val();
        if (parseInt($scope.model.pageNumber) + value > 604)
        { $scope.model.pageNumber = 604 }
            else {
            $scope.model.pageNumber = parseInt($scope.model.pageNumber) + value;
            }
        //goto.pageNumber.value = $scope.pageNumber;
        //if ($scope.pageNumber)
        //var t = goto.pageNumber.validity.valid;
    }
    $scope.subtractValue = function (value)
    {
        //if (num > 604 || num < 1) {
        //    $scope.pageNumber = num;
        //}

        //num = $("#num").val();
        if (parseInt($scope.model.pageNumber) - value < 1) {
            $scope.model.pageNumber = 1
        }
        else {
            $scope.model.pageNumber = parseInt($scope.model.pageNumber) - value;
        }
        //goto.pageNumber.value = $scope.pageNumber;
    }
    $scope.changeText = function (value)
    {
        $scope.model.pageNumber = $("#num").val();
    }
    $scope.submit = function () {
                    if ($scope.model.pageNumber >= 1 && $scope.model.pageNumber <= 604) {
            $state.go("app.page", { 'page': $scope.model.pageNumber });
        }
    }
    $scope.init = function () {
        $scope.model.pageNumber = 1;

    }
    $scope.init();
}]);