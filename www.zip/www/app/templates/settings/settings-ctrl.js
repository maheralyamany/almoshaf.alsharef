﻿app.controller("settingsController", ["$scope", "settings", "recitations", "device", "backup", "$state", function ($scope, settings, recitations, device, backup, $state) {

    $scope.init = function(){
            $scope.model = settings.settingsData;
            $scope.recitations = recitations.recitations;
            console.log($scope.model.recitationId)
            $scope.model.recitationId = settings.settingsData.recitationId.toString();
    }
    $scope.goToBackup = function () {
        console.log("click")
        $scope.user = backup.getUserData();

        if (typeof ($scope.user) == "undefined") {
            $state.go("app.register")
        }
        else {
            $state.go("app.backup")
        }
    }
    $scope.goToCP = function () {
        $state.go("app.ControlPanel");
    }
    $scope.changeMarkMemorizedAyat = function () {
        console.log($scope.model.markMemorizedAyat)
        settings.setMarkMemorizedAyatValue($scope.model.markMemorizedAyat)
    }
    $scope.isAndroid = true;
 // $scope.isAndroid =  device.getPlatform() == "android"
    $scope.changeFullScreen = function () {
        settings.setFullScreenValue($scope.model.fullScreen)
    }
    $scope.changeRecitation = function () {
        console.log($scope.model.recitationId)
        settings.setRecitationIdValue($scope.model.recitationId);
        recitations.setCurrentRecitation($scope.model.recitationId)
    }
    $scope.rate = function () {
        AppRate.preferences.customLocale = {
            title: "قيم %@",
            message: "إذا أعجبك برنامج %@ ، هل تمانع تقييمه؟ شكراً لدعمك",
            cancelButtonLabel: "لا, شكراً",
            laterButtonLabel: "ذكرني لاحقاً  ",
            rateButtonLabel: "قيم البرنامج الآن",
            yesButtonLabel: "نعم!",
            noButtonLabel: "لا",
            appRatePromptTitle: 'اذا اعجبك برنامج %@',
            feedbackPromptTitle: 'هل تمانع ان تشاركنا رايك?',
        };
        AppRate.preferences.storeAppURL = {
       
            android: 'https://play.google.com/store/apps/details?id=com.almoshaf.alsharef',
            
       
        };
        AppRate.preferences.useLanguage = 'ar';
        AppRate.promptForRating(true);
    }
    $scope.changeNightMode = function () {
        settings.setNightModeValue($scope.model.nightMode);
    }
    $scope.changeOrientation = function () {

        if ($scope.model.orientation) {
            screen.orientation.unlock();
            screen.orientation.lock('landscape');
        }
        else {
            screen.orientation.unlock();
            screen.orientation.lock('portrait');
        }

    }
    $scope.keepAwake = function () {

        if ($scope.model.keepAwake) {
            window.plugins.insomnia.keepAwake(function () {
                debugger
               // window.plugins.insomnia.keepAwake();
                console.log("suceesss awake")
            }, function () {
                debugger
                console.log("fail awake")
            });
            //window.plugins.insomnia.keepAwake();
            settings.setkeepAwake(true);
        }
        else {
             
            window.plugins.insomnia.allowSleepAgain(function () {
                debugger;
                //window.plugins.insomnia.allowSleepAgain();
                console.log("suceesss sleep")
            }, function () {
                debugger;
                console.log("fail sleep")
            });
            //window.plugins.insomnia.allowSleepAgain();
            settings.setkeepAwake(false);
        }

    }
    $scope.init();
}]);
