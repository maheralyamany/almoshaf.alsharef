﻿app.controller("memorizedController", function ($scope, moshafdata, memorizedayat, $filter, $ionicPopup, $timeout, $anchorScroll, $location, ionicLoading, target, enums, $state) {
    $scope.init = function () {
        $scope.start = 0;
        $scope.end = 20;
        $scope.noMoreItemsAvailable = false;
        moshafdata.surahs.forEach(function (surah) {

            surah.memorizedayat = memorizedayat.getSurahMemorizedAyat(surah.Id);
        })

        var memorized = moshafdata.surahs.filter(function (surah) { return surah.memorizedayat.length > 0 })
 
        $scope.memorizedList = [];

        memorized.forEach(function (surah) {
            $scope.memorizedList.push(surah);
            surah.isCompleted = surah.memorizedayat.length == surah.AyatCount;
            if (!surah.isCompleted) {
                var ayatArray = angular.copy(surah.memorizedayat);
                ayatArray.forEach(function (el) {
                    debugger;

                    var i = ayatArray.indexOf(el)
                    debugger;
                    if (i > 0 && !(ayatArray[i - 1].id == el.id - 1)) {
                        //  newArr.push(el)
                        var surahCopy = angular.copy(surah)

                        $scope.memorizedList[$scope.memorizedList.length - 1].memorizedayat = ayatArray.filter(function (aya) {
                            return aya.id < el.id
                        })
                        surahCopy.memorizedayat = ayatArray.filter(function (aya) {
                            return aya.id >= el.id
                        })
                        $scope.memorizedList.push(surahCopy)
                        ayatArray = surahCopy.memorizedayat;
                    }
                    //  console.log(newArr)
                    //   return newArr;
                })
            }
        })
        $scope.viewMemorizedList = $scope.memorizedList.slice($scope.start, $scope.end);
        $scope.start += 20;
        $scope.end += 20;
    }


    $scope.loadMore = function () {
        console.log("loading more")

        $scope.viewMemorizedList = $scope.viewMemorizedList.concat($scope.memorizedList.slice($scope.start, $scope.end));
        $scope.start += 20;
        $scope.end += 20;
        if ($scope.viewMemorizedList.length >= $scope.memorizedList.length) {

            $scope.noMoreItemsAvailable = true;
        }
        $scope.$broadcast('scroll.infiniteScrollComplete');
    };
    $scope.init();
  //  console.log($scope.memorizedList);
})
