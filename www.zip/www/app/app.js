﻿/// <reference path="templates/search/search.html" /> 
var storedLocalNotification = null;
var app = angular.module('moshafk', ['ionic', 'ngCordova', 'ionic-timepicker', 'ngSanitize', 'ionic.ion.imageCacheFactory', 'toaster'])

document.addEventListener("deviceready", function () {
    cordova.plugins.notification.local.on("click", function (notification) {
        alert("setting local notification");
        storedLocalNotification = notification;
    });
}, false);

app.run(function ($ionicPlatform, localStorage, $rootScope, $ionicNavBarDelegate, $stateParams, $cordovaNetwork, $state, ionicLoading, device, localNotification, $cordovaLocalNotification, contacts, target, memorizedayat, enums, moshafdb, mark, moshafdata, ayatData, $q, downloadSoarImage, $timeout, file, $ionicHistory, settings, ayatTafseer, audio, reviewTarget, file, fileTransfer, network, $ionicLoading, $ionicModal, permissions) {
    $rootScope.activeTab = 'surah';
    $rootScope.imagesPathInDevice = "file:///storage/emulated/0/Moshaf/Images/";
    $rootScope.nightMode = settings.settingsData.nightMode;

    $rootScope.search = function () {
        $rootScope.searchIcon = true;
        $state.go("app.search");
    }

    if (localStorage.get("firstTime") == undefined) {
        localStorage.set("firstTime", true);
    }
    else {
        localStorage.set("firstTime", false);
    }

    $rootScope.getArabicNumber = function (num) {
        if (typeof (num) == "number")
            return num.toIndiaDigits();
    }
    //Set this flag to true in development  (to enable //alerts)

    function handleNotificationClickEvent(notification) {
        alert(JSON.stringify(notification));
        try {
            alert(typeof (notification.data));
            var data = angular.fromJson(notification.data);
            var targetData = data.targetData;
            //   alert(JSON.stringify(targetData));
            if (targetData.targetMode == enums.targetMode.werd) {
                target.data = targetData;
                if (targetData.memorizeMode == enums.memorizeMode.group) {
                    console.log("synching from local to server");
                    memorizedayat.syncMemorizedAyatLocalToServer();
                }

                console.log("going to memorize mode");
                isPageRedirected = true;
                //if (localStorage.get("firstTime") != undefined) {
                $timeout(function () {
                    $state.go("app.page", { target: targetData.id });
                }, 300);

                //    $state.go("app.test", { target: targetData.id });
            }
            else {
                reviewTarget.data = targetData;
                console.log("going to memorize mode");
                isPageRedirected = true;
                //if (localStorage.get("firstTime") != undefined) {
                $state.go("app.page", { reviewTarget: targetData.id });
                //  $state.go("app.test", { target: targetData.id });
            }
            //}
            //else {

            //    $state.go("app.help");
            //    localStorage.set("firstTime", false);
            //}
        }
        catch (ex) {
            alert(JSON.stringify(ex));
        }

    }

    function goToLastPageAndMode() {

        var lastPage = mark.getLastPage();
        alert(lastPage);
        $rootScope.lastPage = lastPage;

        //if (localStorage.get("firstTime") != undefined) {
        if (lastPage.mode == enums.appModes.memorize) {
            $state.go("app.page", { page: lastPage.pageNumber, target: lastPage.target });
            //$state.go("app.test", { page: lastPage.pageNumber, target: lastPage.target });

            $rootScope.appMode = enums.appModes.memorize;
        }
        else if (lastPage.mode == enums.appModes.review) {
            $state.go("app.page", { page: lastPage.pageNumber, reviewTarget: lastPage.target });
            $rootScope.appMode = enums.appModes.review;
        }
        else {
            $state.go("app.page", { page: lastPage.pageNumber });
            //$state.go("app.test", { page: lastPage.pageNumber });

            $rootScope.appMode = enums.appModes.read;
        }
    }

    function setFullScreenMode() {
        var devicePlatform = device.platform;
        if (devicePlatform != "Android" && typeof (window.StatusBar) != "undefined") {
            StatusBar.styleLightContent();
        }
        if (settings.settingsData.fullScreen) {
            if (typeof (AndroidFullScreen) != "undefined") {
                if (devicePlatform == "Android")
                    AndroidFullScreen.immersiveMode()
                else
                    StatusBar.hide();
            }


        }
        else {
            if (devicePlatform == "Android")


                AndroidFullScreen.showSystemUI();


            else
                StatusBar.show();
        }
    }

    var debugMode = false;
    var isPageRedirected = false; //flag to check if the page should be redirected to another page or not
    if (!debugMode) {
        window.alert = function (msg) {
            // console.log(msg);
        }
    }

    $ionicPlatform.ready(function () {
        setFullScreenMode();

        //For the notifications that come while the application is on background (in recent apps)
        if (typeof (cordova) != "undefined") {
            cordova.plugins.notification.local.on("click", function (notification) {
                alert("handling background notification (in recent apps)");
                handleNotificationClickEvent(notification);
            });
        }
        if (storedLocalNotification != null) {
            alert("handling notification from ionic ready");
            handleNotificationClickEvent(storedLocalNotification);
        }

        if (typeof (cordova) != "undefined") {
            window.addEventListener('native.keyboardshow', function (e) {

                if ($(".pull-up").length > 0) {
                    var keyboardHeight = e.keyboardHeight;
                    var windowHeight = window.innerHeight;

                    $.each($(".pull-up"), function (i, el) {
                        var popupHeight = $(el).height();
                        $(el).css({ top: windowHeight - (keyboardHeight + popupHeight) + 'px' })
                    })
                }

            });

            window.addEventListener('native.keyboardhide', function (e) {

                if ($(".pull-up").length > 0) {
                    $.each($(".pull-up"), function (i, el) {
                        $(el).removeAttr('style');
                    });

                }
                setFullScreenMode();

            });
        }

        if (window.cordova && window.cordova.plugins.Keyboard) {
            // Hide the accessory bar by default (remove this to show the accessory bar above the keyboard
            // for form inputs)
            cordova.plugins.Keyboard.hideKeyboardAccessoryBar(true);
            // Don't remove this line unless you know what you are doing. It stops the viewport
            // from snapping when text inputs are focused. Ionic handles this internally for
            // a much nicer keyboard experience.
            cordova.plugins.Keyboard.disableScroll(true);
        }
 //permissions
        var permissions = cordova.plugins.permissions;
        permissions.requestPermission(permissions.READ_EXTERNAL_STORAGE, success, error);
        function error() {
            console.warn('READ_EXTERNAL_STORAGE permission is not turned on');
        }
        function success(status) {
            if (!status.hasPermission) error();
            downloadImages();
        }
        //orintaion
        screen.orientation.lock('portrait');
        //keepAwake

        if (settings.settingsData.keepAwake) {
            window.plugins.insomnia.keepAwake(function () {
                debugger
               // window.plugins.insomnia.keepAwake();
                console.log("suceesss awake")
            }, function () {
                debugger
                console.log("fail awake")
            });
           // window.plugins.insomnia.keepAwake();
        }
        else {
            window.plugins.insomnia.allowSleepAgain(function () {
                debugger;
                //window.plugins.insomnia.allowSleepAgain();
                console.log("suceesss sleep")
            }, function () {
                debugger;
                console.log("fail sleep")
            });
            //window.plugins.insomnia.allowSleepAgain();
        }

    });

    //Handle Hardware Back Button

    $ionicPlatform.on("resume", function (event) {
        // will execute when device resume.
        setFullScreenMode();
    });
    $ionicPlatform.registerBackButtonAction(function () {

        if ($state.current.name == "app.page") {
            navigator.app.exitApp();
        } else {

            if ($ionicHistory.backView() == null || $ionicHistory.backView().stateName == "app.page") {
                goToLastPageAndMode();
            }

            else {
                navigator.app.backHistory();
            }
        }
    }, 100);
    $rootScope.$on('$stateChangeSuccess', function (event, toState, toParams, fromState, fromParams) {
        if (toState.name == "parts") ionicHistory.removeBackView();
        //if(fromState.name=="app.page")
        //{
        audio.stop();
        //}
    });

    ////////////////////////////////////////////////////////////////////////////
    function initMoshafDB() {
        moshafdb.initDb().then(function () {
            var surahsPromise = moshafdata.getSurahs();
            surahsPromise.then(function (result) {
                ayatData.surahs = result;
            });

            var partsPromise = moshafdata.getParts();
            partsPromise.then(function (result) {
                ayatData.juzs = result;
            })

            var ayatPromise = moshafdata.getAyat();
            ayatPromise.then(function (result) {
                //alert("done aya");
                ayatData.ayat = result.sort(function (a, b) {
                    return a.id - b.id;
                });

            });

            var ayatTafseerPromise = moshafdata.getAyatTafseer();
            ayatTafseerPromise.then(function (result) {
                ayatTafseer.ayatTafseer = result.sort(function (a, b) {
                    return a.id - b.id;

                });
            });

            $q.all([surahsPromise, partsPromise, ayatPromise, ayatTafseerPromise]).then(function () {
                goToLastPageAndMode();
            })

        });
    }
    function downloadImages() {
        var downloader = new BackgroundTransfer.BackgroundDownloader();
        var directoryName = cordova.file.externalApplicationStorageDirectory;
        var path = directoryName + "files";
        if (device.getPlatform() == "ios") {
            directoryName = cordova.file.dataDirectory;
            path = directoryName + "Almoshaf Alshareef/images";
        }

        console.log(directoryName);
        console.log(path);
        var downloadedCount = 0;
        $rootScope.downloadingPercentage = 0;
        function listDir(path) {
            window.resolveLocalFileSystemURL(path,
              function (fileSystem) {
                  var reader = fileSystem.createReader();
                  console.log(reader);
                  reader.readEntries(
                    function (entries) {
                        exsitImgs = entries;
                        console.log(entries);
                        if (entries.length < 604) {
                            $rootScope.modal.show();
                            var pageNum = 1;
                            downloadeImage(pageNum);
                        }
                        else {
                            initMoshafDB();
                        }
                    },
                    function (err) {
                        console.log(err);
                    }
                  );
              }, function (err) {
                  console.log(err);
              }
            );
        }

        listDir(path);

        function downloadeImage(pageNumber) {
            var directoryName = cordova.file.externalApplicationStorageDirectory;
            var path = directoryName + "files";
            var pageName = pageNumber < 10 ? "page00" + pageNumber : pageNumber < 100 ? "page0" + pageNumber : "page" + pageNumber;
            var sourceUrl = enums.appData.imagesLink + pageName + ".png";
            var filePath = path + "/" + pageName + ".png";
			  var fileName = enums.appData.target + pageName + ".png"; 
      // if (device.getPlatform() == "ios") {
      //        fileName = path+"/" + pageName + ".png"; 
      //  }
 
		
            file.checkFile(fileName).then(function (success) {
                console.log(fileName + " exist");
                pageNumber++;
                if (pageNumber <= 604) {
                    downloadeImage(pageNumber)
                }
            }, function (error) {
                console.log(error);
                console.log(fileName + " not found");
                if (network.isOnline()) {

                    //fileTransfer.download(sourceUrl, filePath, "").then(function (ret) {
                    //    downloadedCount++;
                    //    $rootScope.downloadingPercentage = downloadedCount * (100 / 604);
                    //    console.log(filePath + " downloaded");
                    //    pageNumber++;
                    //    if (pageNumber <= 604) {
                    //        downloadeImage(pageNumber)
                    //    }
                    //    if (pageNumber == 605) {
                    //        $rootScope.modal.hide();
                    //        initMoshafDB();
                    //    }
                    //}).then(function (err) {

                    //});
                    window.resolveLocalFileSystemURL(path, function (dirEntry) {
                        dirEntry.getFile(pageName + ".png", { create: true }, function (targetFile) {
                            // Create a new download operation.
                            var download = downloader.createDownload(sourceUrl, targetFile);
                            // Start the download and persist the promise to be able to cancel the download.
                            app.downloadPromise =download.startAsync().then(function (suc) {
                                console.log(suc);
                                downloadedCount = pageNumber;
                                    $rootScope.downloadingPercentage = downloadedCount * (100 / 604);
                                pageNumber++;
                                if (pageNumber <= 604) {
                                    downloadeImage(pageNumber)
                                }
                                if (pageNumber == 605) {
                                    $rootScope.modal.hide();;
                                    initMoshafDB();

                                }
                            }, function (err) { console.log(error); }, function (prog) { console.log(prog); });
                        })
                    }, function (error) {
                        console.log(error)
                        console.log("error")
                    })
                }
                else {
                    network.showNetworkOfflineMsg();
                }

            });

        }


    }

    $ionicModal.fromTemplateUrl('app/templates/popovers/loading.html', {
        scope: $rootScope,
        animation: 'slide-in-up',
    }).then(function (modal) {
        $rootScope.modal = modal;

    });
    ////////////////////////////////////////////////////////////////////////////
})

.config(function ($stateProvider, $urlRouterProvider, $ionicConfigProvider) {

    $ionicConfigProvider.views.maxCache(0);
    $ionicConfigProvider.views.swipeBackEnabled(false);
    //Back Button settings
    $ionicConfigProvider.backButton.text('').previousTitleText(false);
    $ionicConfigProvider.scrolling.jsScrolling(true);

    $stateProvider

        .state('app', {
            abstract: true,
            url: "/app",
            templateUrl: "app/layouts/side-menu.html"
        })
           .state('app.tabs', {
               url: "/tabs",
               //cache: false,
               views: {
                   "mainContent": {
                       templateUrl: "app/layouts/tabs.html"
                   }
               }
           })
          .state('header', {
              abstract: true,
              url: "/header",
              templateUrl: "app/layouts/side-menu.html"
          })
         .state('app.page', {
             url: "/page/:page/:aya/:target/:date/:reviewTarget/:repeatMode/:ayaEnd/:repeatCount",
             cache: false,
             views: {
                 "mainContent": {
                     templateUrl: "app/templates/quran/page.html"
                 }
             }
         })
            .state('app.test', {
                url: "/page/:page/:aya/:target/:date/:reviewTarget",
                //cache: false,
                views: {
                    "mainContent": {
                        templateUrl: "app/templates/testTajweed/page.html"
                    }
                }
            })
            .state('app.guides', {
                url: "/guides",
                //  cache: false,
                views: {
                    "mainContent": {
                        templateUrl: "app/templates/help/guides.html"
                    }
                }
            })
            .state('app.home', {
                url: "/home",
                //  cache: false,
                views: {
                    "mainContent": {
                        templateUrl: "app/templates/home/home.html"
                    }
                }
            })
        .state('app.memorized', {
            url: "/memorized",
            //  cache: false,
            views: {
                "mainContent": {
                    templateUrl: "app/templates/memorize/memorized.html"
                }
            }
        })

             .state('app.un-memorized', {
                 url: "/unMemorized",
                 //  cache: false,
                 views: {
                     "mainContent": {
                         templateUrl: "app/templates/memorize/un-memorized.html"
                     }
                 }
             })

     .state('app.set-target-details', {
         url: "/setTargetDetails/:mode",
         cache: false,
         views: {
             "mainContent": {
                 templateUrl: "app/templates/target/set-target-details.html"
             }
         }
     })

     .state('app.set-target-duration', {
         url: "/setTargetDuration",
         cache: false,
         views: {
             "mainContent": {
                 templateUrl: "app/templates/target/set-target-duration.html"
             }
         }
     })


         .state('app.target-list', {
             url: "/target",
             cache: false,
             views: {
                 "mainContent": {
                     templateUrl: "app/templates/target/target-list.html"
                 }
             }
         })
        .state('app.search', {
            url: "/search",
            // cache: false,
            views: {
                "mainContent": {
                    templateUrl: "app/templates/search/search.html"
                }
            }
        })
          .state('app.searchResult', {
              url: "/searchResult",
              //  cache: false,
              views: {
                  "mainContent": {
                      templateUrl: "app/templates/search/searchResult.html"
                  }
              }
          })
              .state('app.tabs.parts', {
                  url: "/parts",
                  cache: false,
                  views: {
                      "mainContent": {
                          templateUrl: "app/templates/parts/partsList.html"
                      }
                      ,
                      'tab-servicos': {
                          templateUrl: "app/templates/parts/partsList.html"
                      }
                  }
              })
     .state('app.tabs.surahs', {
         url: "/surahs",
         cache: true,
         views: {
             "mainContent": {
                 templateUrl: "app/templates/surahs/surahsList.html"
             },
             'tab-servicos': {
                 templateUrl: "app/templates/surahs/surahsList.html"
             }
         }
     })
         .state('app.tabs.pages', {
             url: "/pages",
             cache: true,
             views: {
                 "mainContent": {
                     templateUrl: "app/templates/pages/pages.html"
                 },
                 'tab-servicos': {
                     templateUrl: "app/templates/pages/pages.html"
                 }
             }
         })
    .state('app.bookmarks', {
        url: "/bookmarks",
        //    cache: false,
        views: {
            "mainContent": {
                templateUrl: "app/templates/marks/marksList.html"
            }
        }
    })
            .state('app.notes', {
                url: "/notes",
                //    cache: false,
                views: {
                    "mainContent": {
                        templateUrl: "app/templates/notes/notesList.html"
                    }
                }
            })
     .state('app.about', {
         url: "/about",
         //    cache: false,
         views: {
             "mainContent": {
                 templateUrl: "app/templates/aboutApp/about.html"
             }
         }
     })

           .state('app.settings', {
               url: "/settings",
               //    cache: false,
               views: {
                   "mainContent": {
                       templateUrl: "app/templates/settings/settings.html"
                   }
               }
           })
         .state('app.register', {
             url: "/register",
             //    cache: false,
             views: {
                 "mainContent": {
                     templateUrl: "app/templates/Backup/register.html"
                 }
             }
         })
         .state('app.login', {
             url: "/login",
             //    cache: false,
             views: {
                 "mainContent": {
                     templateUrl: "app/templates/Backup/login.html"
                 }
             }
         })
            .state('app.backup', {
                url: "/backup",
                //    cache: false,
                views: {
                    "mainContent": {
                        templateUrl: "app/templates/Backup/backup.html"
                    }
                }
            })
      .state('app.set-review-target-details', {
          url: "/setReviewTargetDetails",
          cache: false,
          views: {
              "mainContent": {
                  templateUrl: "app/templates/reviewTarget/set-review-target-details.html"
              }
          }
      })

     .state('app.set-review-target-duration', {
         url: "/setReviewTargetDuration",
         cache: false,
         views: {
             "mainContent": {
                 templateUrl: "app/templates/reviewTarget/set-review-target-duration.html"
             }
         }
     })


         .state('app.review-target-list', {
             url: "/reviewTarget",
             cache: false,
             views: {
                 "mainContent": {
                     templateUrl: "app/templates/reviewTarget/review-target-list.html"
                 }
             }
         })
         .state('app.ControlPanel', {
             url: "/ControlPanel",
             views: {
                 "mainContent": {
                     templateUrl: "app/templates/ControlPanel/ControlPanel.html"
                 }
             }
         })
        .state('app.downloadTelawas', {
            url: "/downloadTelawas",
            views: {
                "mainContent": {
                    templateUrl: "app/templates/download-telawas/downloadTelawas.html"
                }
            }
        })
        .state('app.telawa-surahs', {
            url: "/telawa-surahs",
            views: {
                "mainContent": {
                    templateUrl: "app/templates/telawa-surahs/telawa-surahs.html"
                }
            }
        })
        .state('app.surah-audios', {
            url: "/surah-audios",
            views: {
                "mainContent": {
                    templateUrl: "app/templates/surah-audios/surah-audios.html"
                }
            }
        })
       .state('app.doaa', {
           url: "/doaa/:doaaActive",
           cache: false,
           views: {
               "mainContent": {
                   templateUrl: "app/templates/doaa/doaa.html"
               }
           }
       })
    /*

    //   $urlRouterProvider.otherwise('/app/home');
    $urlRouterProvider.otherwise(function ($injector, $location) {
        $injector.invoke(['$state', function ($state) {
            $state.go('app.home');
        }]);
    });
    */

})

Number.prototype.toIndiaDigits = function () {// to convert numbers to arabic 
    var id = ['٠', '١', '٢', '٣', '٤', '٥', '٦', '٧', '٨', '٩'];
    return this.toString().replace(/[0-9]/g, function (w) {
        return id[+w]
    });
}
//var platformType = "";
//if (typeof (cordova) != "undefined") {
//    if (device.getPlatform() == 'android' || device.getPlatform() == "amazon-fireos") {
//        platformType = "android";
//    }
//    else {
//        platformType = "ios"
//    }
//}